import json
import csv
from django.http import HttpResponse
from django.contrib.auth import update_session_auth_hash
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from .models import Paciente, AtendimentoTriagem
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from .models import UnidadeSaude, PerfilAcesso
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.utils import timezone
from datetime import timedelta

def pagina_login(request):
    erro = None
    if request.method == 'POST':
        usuario_digitado = request.POST.get('usuario')
        senha_digitada = request.POST.get('senha')
        unidade_selecionada = request.POST.get('unidade')

        user = authenticate(request, username=usuario_digitado, password=senha_digitada)

        if user is not None:
            try:
                perfil = PerfilAcesso.objects.get(usuario=user)
                
                # Permite acesso se a unidade estiver vinculada OU se for ADMIN (Admin acessa tudo)
                if perfil.unidades.filter(id=unidade_selecionada).exists() or perfil.tipo_perfil == 'ADMIN':
                    login(request, user)
                    
                    # Grava a unidade escolhida na sessão
                    request.session['unidade_id'] = unidade_selecionada
                    
                    # --- TRAVA DE SEGURANÇA: TROCA DE SENHA OBRIGATÓRIA ---
                    if getattr(perfil, 'deve_trocar_senha', False):
                        return redirect('trocar_senha')
                    # ------------------------------------------------------
                    
                    # Redireciona para o painel correto de acordo com o perfil
                    if perfil.tipo_perfil == 'ENFERMAGEM':
                        return redirect('triagem')
                    elif perfil.tipo_perfil == 'ADMIN':
                        return redirect('painel_admin')
                    else:
                        return redirect('medico')
                else:
                    erro = "Acesso negado para esta unidade de saúde."
            except PerfilAcesso.DoesNotExist:
                erro = "Este usuário não possui um perfil de acesso configurado."
        else:
            erro = "Usuário ou senha incorretos."

    return render(request, 'login.html', {'erro': erro})

@login_required
def pagina_triagem(request):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    
    # BARREIRA: Apenas Enfermagem e Administrador Full podem acessar aqui
    if perfil.tipo_perfil not in ['ENFERMAGEM', 'ADMIN']:
        # Se for Médico ou Administrativo, chuta de volta para o monitoramento
        return redirect('medico')
        
    contexto = {
        'nome_usuario': request.user.first_name or request.user.username,
        'perfil_nome': perfil.get_tipo_perfil_display()
    }
    return render(request, 'triagem.html', contexto)

@login_required
def pagina_medico(request):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    
    if perfil.tipo_perfil not in ['MEDICO', 'ADMINISTRATIVO', 'ADMIN']:
        return redirect('triagem')
        
    # --- CORREÇÃO: PEGA APENAS A UNIDADE DA SESSÃO ---
    unidade_id = request.session.get('unidade_id')
    if not unidade_id:
        return redirect('sair') # Chuta para fora se perdeu a sessão
        
    unidade_ativa = UnidadeSaude.objects.get(id=unidade_id)

    # Busca todos os atendimentos APENAS da unidade ativa
    atendimentos = AtendimentoTriagem.objects.filter(unidade=unidade_ativa)

    # --- NOVO: FILTRO DE PERÍODO ---
    # Lê o que o utilizador escolheu no menu (por padrão, mostra 'todos')
    # --- NOVO: FILTRO DE PERÍODO COM DATAS CUSTOMIZADAS ---
    periodo_escolhido = request.GET.get('periodo', 'todos')
    data_inicio = request.GET.get('data_inicio', '')
    data_fim = request.GET.get('data_fim', '')
    agora = timezone.now()

    if periodo_escolhido == 'hoje':
        hoje_inicio = agora.replace(hour=0, minute=0, second=0, microsecond=0)
        atendimentos = atendimentos.filter(data_hora_triagem__gte=hoje_inicio)
    elif periodo_escolhido == '7dias':
        limite = agora - timedelta(days=7)
        atendimentos = atendimentos.filter(data_hora_triagem__gte=limite)
    elif periodo_escolhido == '30dias':
        limite = agora - timedelta(days=30)
        atendimentos = atendimentos.filter(data_hora_triagem__gte=limite)
    elif periodo_escolhido == 'personalizado':
        # __date__gte verifica se a data é Maior ou Igual (Greater Than or Equal)
        if data_inicio:
            atendimentos = atendimentos.filter(data_hora_triagem__date__gte=data_inicio)
        # __date__lte verifica se a data é Menor ou Igual (Less Than or Equal)
        if data_fim:
            atendimentos = atendimentos.filter(data_hora_triagem__date__lte=data_fim)

    # Ordena do mais recente para o mais antigo após filtrar
    atendimentos = atendimentos.order_by('-data_hora_triagem')
    # -------------------------------

    # Ordena do mais recente para o mais antigo após filtrar
    atendimentos = atendimentos.order_by('-data_hora_triagem')
    # -------------------------------

    # 3. Faz a contagem para os cartões gerenciais
    total_pacientes = atendimentos.count()
    alto_risco = atendimentos.filter(classificacao_risco='Alto').count()
    medio_risco = atendimentos.filter(classificacao_risco='Médio').count()
    baixo_risco = atendimentos.filter(classificacao_risco='Baixo').count()
    
    # 4. Filtra os Alertas Críticos (Alto Risco e que ainda não foram reconhecidos)
    alertas_pendentes = atendimentos.filter(classificacao_risco='Alto', alerta_reconhecido=False)
    qtd_nao_reconhecidos = alertas_pendentes.count()

    # 5. Prepara a "bandeja" para entregar ao ecrã HTML
    contexto = {
        'nome_usuario': request.user.first_name or request.user.username,
        'perfil_nome': perfil.get_tipo_perfil_display(),
        'periodo_atual': periodo_escolhido, # Mandamos de volta para o menu saber o que está selecionado
        'data_inicio': data_inicio, # NOVO
        'data_fim': data_fim,       # NOVO
        
        # Números para os cartões
        'total_pacientes': total_pacientes,
        'alto_risco': alto_risco,
        'medio_risco': medio_risco,
        'baixo_risco': baixo_risco,
        'qtd_nao_reconhecidos': qtd_nao_reconhecidos,
        
        # Listas para popular o ecrã
        'alertas_recentes': alertas_pendentes[:5], 
        'grade_pacientes': atendimentos[:12]       
    }
    
    return render(request, 'medico.html', contexto)

@login_required
def pagina_paciente(request, id):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    
    if perfil.tipo_perfil not in ['MEDICO', 'ADMINISTRATIVO', 'ADMIN']:
        return redirect('triagem')
        
    # Busca o atendimento exato que o médico clicou
    atendimento = get_object_or_404(AtendimentoTriagem, id=id)
    
    # Barreira de Segurança extra: Este atendimento é de uma unidade que este médico atende?
    if atendimento.unidade not in perfil.unidades.all():
        return redirect('medico') # Se não for, chuta ele de volta

    contexto = {
        'nome_usuario': request.user.first_name or request.user.username,
        'perfil_nome': perfil.get_tipo_perfil_display(),
        'atendimento': atendimento # Mandamos todos os dados do paciente para a tela
    }
    return render(request, 'paciente_detalhe.html', contexto)

@login_required
def reconhecer_alerta(request, id):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    
    # O comando abaixo pega a URL da página em que o usuário estava quando clicou no botão
    pagina_anterior = request.META.get('HTTP_REFERER', 'medico')
    
    # Regra do Projeto: Administrativo não pode reconhecer alertas
    if perfil.tipo_perfil not in ['MEDICO', 'ADMIN']:
        return redirect(pagina_anterior)
        
    atendimento = get_object_or_404(AtendimentoTriagem, id=id)
    unidade_id = request.session.get('unidade_id')
    
    # Se o atendimento for da unidade atual da sessão, marca como reconhecido e anota o médico
    if str(atendimento.unidade.id) == str(unidade_id):
        atendimento.alerta_reconhecido = True
        atendimento.medico_reconheceu = request.user # Grava o usuário logado!
        atendimento.save()
        
    # Devolve o usuário para a tela em que ele estava (seja o painel ou os detalhes do paciente)
    return redirect(pagina_anterior)

# === NOVA FUNÇÃO PARA SAIR DO SISTEMA ===
def sair_sistema(request):
    logout(request) # Destrói a sessão segura do usuário
    return redirect('login') # Manda de volta pra tela inicial

# === NOVA FUNÇÃO PARA BUSCAR UNIDADES DINAMICAMENTE ===
def buscar_unidades_usuario(request):
    # Pega o nome de usuário que a tela enviou
    username = request.GET.get('usuario', None)
    dados = []
    
    if username:
        try:
            # Tenta encontrar o usuário e o perfil dele no banco
            user = User.objects.get(username=username)
            perfil = PerfilAcesso.objects.get(usuario=user)
            
            # Pega apenas as unidades vinculadas a este perfil específico
            unidades = perfil.unidades.all()
            
            for unidade in unidades:
                dados.append({
                    'id': unidade.id,
                    'nome': unidade.nome
                })
        except (User.DoesNotExist, PerfilAcesso.DoesNotExist):
            # Se o usuário não existir ou não tiver perfil, a lista continuará vazia
            pass 
            
    return JsonResponse({'unidades': dados})

    # A calculadora matemática do NEWS    <========================================== NEWS
def calcular_score_news(dados):
    score = 0
    try:
        fr = int(dados.get('freq_respiratoria') or 0)
        if fr <= 8 or fr >= 25: score += 3
        elif fr in range(21, 25): score += 2
        elif fr in range(9, 12): score += 1

        sat = int(dados.get('saturacao_o2') or 0)
        if sat <= 91: score += 3
        elif sat in range(92, 94): score += 2
        elif sat in range(94, 96): score += 1

        if dados.get('uso_o2_suplementar') == 'Sim': score += 2

        temp = float(dados.get('temperatura') or 0)
        if temp <= 35.0: score += 3
        elif temp >= 39.1: score += 2
        elif 35.1 <= temp <= 36.0 or 38.1 <= temp <= 39.0: score += 1

        pas = int(dados.get('pressao_sistolica') or 0)
        if pas <= 90 or pas >= 220: score += 3
        elif 91 <= pas <= 100: score += 2
        elif 101 <= pas <= 110: score += 1

        fc = int(dados.get('freq_cardiaca') or 0)
        if fc <= 40 or fc >= 131: score += 3
        elif 111 <= fc <= 130: score += 2
        elif 41 <= fc <= 50 or 91 <= fc <= 110: score += 1

        consciencia = dados.get('nivel_consciencia')
        if consciencia != 'Alerta': score += 3

        if score >= 7:
            risco = 'Alto'
            conduta = 'Revisão médica imediata necessária. Alerta clínico enviado.'
        elif score >= 5:
            risco = 'Médio'
            conduta = 'Avaliação médica urgente. Aumentar monitoramento.'
        else:
            risco = 'Baixo'
            conduta = 'Manter monitoramento padrão da unidade.'

        return score, risco, conduta
    except ValueError:
        return 0, 'Baixo', 'Erro ao calcular (verifique os números digitados).'

# A calculadora matemática do PEWS (Pediátrico) - Versão Simplificada
def calcular_score_pews(dados):
    score = 0
    try:
        # 1. Comportamento / Nível de Consciência
        consciencia = dados.get('nivel_consciencia')
        if consciencia in ['Confusão', 'Voz']: score += 1
        elif consciencia == 'Dor': score += 2
        elif consciencia == 'Inconsciente': score += 3

        # 2. Cardiovascular (Frequência Cardíaca)
        fc = int(dados.get('freq_cardiaca') or 0)
        if fc < 60 or fc > 160: score += 3
        elif fc > 140: score += 2
        elif fc < 70 or fc > 120: score += 1

        # 3. Respiratório (Frequência Respiratória)
        fr = int(dados.get('freq_respiratoria') or 0)
        if fr < 15 or fr > 50: score += 3
        elif fr > 40: score += 2
        elif fr < 20 or fr > 30: score += 1

        # 4. Saturação e Oxigênio
        sat = int(dados.get('saturacao_o2') or 0)
        if sat <= 89: score += 3
        elif 90 <= sat <= 93: score += 2
        elif 94 <= sat <= 95: score += 1

        if dados.get('uso_o2_suplementar') == 'Sim': score += 2

        # Gatilhos de Risco Pediátrico
        if score >= 7:
            risco = 'Alto'
            conduta = 'PEWS Crítico: Acionar equipe de emergência pediátrica imediatamente.'
        elif score >= 4:
            risco = 'Médio'
            conduta = 'PEWS Atenção: Avaliação médica em até 30 minutos.'
        else:
            risco = 'Baixo'
            conduta = 'PEWS Normal: Manter monitoramento de rotina.'

        return score, risco, conduta
    except ValueError:
        return 0, 'Baixo', 'Erro ao calcular (verifique os números digitados).'

# A calculadora matemática do MEOWS (Obstétrico)
def calcular_score_meows(dados):
    score = 0
    try:
        # A gestante tem alterações fisiológicas normais, a tabela MEOWS compensa isso
        fr = int(dados.get('freq_respiratoria') or 0)
        if fr < 12 or fr > 25: score += 3
        elif 21 <= fr <= 25: score += 1

        sat = int(dados.get('saturacao_o2') or 0)
        if sat < 92: score += 3
        elif 92 <= sat <= 95: score += 1

        temp = float(dados.get('temperatura') or 0)
        if temp < 35.0 or temp > 38.0: score += 3
        elif 35.0 <= temp <= 35.9 or 37.5 <= temp <= 38.0: score += 1

        fc = int(dados.get('freq_cardiaca') or 0)
        if fc < 50 or fc > 120: score += 3
        elif 111 <= fc <= 120: score += 2
        elif 50 <= fc <= 59 or 101 <= fc <= 110: score += 1

        pas = int(dados.get('pressao_sistolica') or 0)
        if pas < 90 or pas >= 160: score += 3
        elif 150 <= pas <= 159: score += 2
        elif 90 <= pas <= 99 or 140 <= pas <= 149: score += 1

        consciencia = dados.get('nivel_consciencia')
        if consciencia != 'Alerta': score += 3

        # Gatilhos de Risco Obstétrico (Mais sensíveis)
        if score >= 6 or (score >= 3 and consciencia != 'Alerta'):
            risco = 'Alto'
            conduta = 'MEOWS Crítico: Avaliação obstétrica urgente (Risco de pré-eclâmpsia/sepse).'
        elif score >= 4:
            risco = 'Médio'
            conduta = 'MEOWS Atenção: Repetir sinais em 1h e avisar médico plantonista.'
        else:
            risco = 'Baixo'
            conduta = 'MEOWS Normal: Monitoramento padrão.'

        return score, risco, conduta
    except ValueError:
        return 0, 'Baixo', 'Erro ao calcular (verifique os números digitados).'

# A rota que salva no banco de dados
@login_required
def salvar_triagem(request):
    if request.method == 'POST':
        try:
            dados = json.loads(request.body)
            
            # 1. Salva ou encontra o paciente (apenas nome é obrigatório [cite: 9])
            paciente, created = Paciente.objects.get_or_create(
                nome_completo=dados.get('nome').upper(),
                defaults={
                    'cpf': dados.get('cpf'),
                    'data_nascimento': dados.get('nascimento') or None,
                    'nome_mae': dados.get('mae')
                }
            )

            # 2. Direciona para o Protocolo Escolhido na Tela
            protocolo_escolhido = dados.get('protocolo')
            
            if protocolo_escolhido == 'NEWS':
                score, risco, conduta = calcular_score_news(dados)
            elif protocolo_escolhido == 'PEWS':
                score, risco, conduta = calcular_score_pews(dados)
            elif protocolo_escolhido == 'MEOWS':
                score, risco, conduta = calcular_score_meows(dados)
            else:
                score, risco, conduta = 0, 'Baixo', 'Protocolo não reconhecido.'

            # 3. Descobre a unidade baseada na sessão do usuário
            unidade_id = request.session.get('unidade_id')
            if not unidade_id:
                return JsonResponse({'sucesso': False, 'erro': 'Sessão expirada. Faça login novamente.'})
                
            unidade_atual = UnidadeSaude.objects.get(id=unidade_id)

            # 4. Salva o Atendimento
            # 4. Salva o Atendimento (Verifica se é NOVO ou EDIÇÃO)
            atendimento_id = dados.get('atendimento_id')
            
            if atendimento_id:
                # É uma EDIÇÃO: Atualiza os dados existentes
                atendimento = AtendimentoTriagem.objects.get(id=atendimento_id)
                atendimento.paciente = paciente
                atendimento.protocolo = protocolo_escolhido
                atendimento.freq_respiratoria = dados.get('freq_respiratoria') or None
                atendimento.saturacao_o2 = dados.get('saturacao_o2') or None
                atendimento.uso_o2_suplementar = (dados.get('uso_o2_suplementar') == 'Sim')
                atendimento.temperatura = dados.get('temperatura') or None
                atendimento.pressao_sistolica = dados.get('pressao_sistolica') or None
                atendimento.freq_cardiaca = dados.get('freq_cardiaca') or None
                atendimento.nivel_consciencia = dados.get('nivel_consciencia')
                atendimento.score_final = score
                atendimento.classificacao_risco = risco
                atendimento.save()
            else:
                # É um NOVO atendimento
                AtendimentoTriagem.objects.create(
                    paciente=paciente,
                    unidade=unidade_atual,
                    enfermeiro=request.user,
                    protocolo=protocolo_escolhido,
                    freq_respiratoria=dados.get('freq_respiratoria') or None,
                    saturacao_o2=dados.get('saturacao_o2') or None,
                    uso_o2_suplementar=(dados.get('uso_o2_suplementar') == 'Sim'),
                    temperatura=dados.get('temperatura') or None,
                    pressao_sistolica=dados.get('pressao_sistolica') or None,
                    freq_cardiaca=dados.get('freq_cardiaca') or None,
                    nivel_consciencia=dados.get('nivel_consciencia'),
                    score_final=score,
                    classificacao_risco=risco
                )

            return JsonResponse({'sucesso': True, 'score': score, 'risco': risco, 'conduta': conduta})
        except Exception as e:
            return JsonResponse({'sucesso': False, 'erro': str(e)})

@login_required
def historico_triagem(request):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    
    # Apenas Enfermagem e Administrador acessam aqui
    if perfil.tipo_perfil not in ['ENFERMAGEM', 'ADMIN']:
        return redirect('medico')
        
    unidade_id = request.session.get('unidade_id')
    if not unidade_id:
        return redirect('sair')
        
    unidade_ativa = UnidadeSaude.objects.get(id=unidade_id)
    
    # 1. Busca todos os atendimentos da unidade ativa
    atendimentos = AtendimentoTriagem.objects.filter(unidade=unidade_ativa)
    
    # 2. Recebe os filtros da tela
    periodo_escolhido = request.GET.get('periodo', 'hoje')
    data_inicio = request.GET.get('data_inicio', '')
    data_fim = request.GET.get('data_fim', '')
    busca_nome = request.GET.get('busca', '')
    
    agora = timezone.now()
    
    # 3. Aplica o Filtro de Período
    if periodo_escolhido == 'hoje':
        hoje_inicio = agora.replace(hour=0, minute=0, second=0, microsecond=0)
        atendimentos = atendimentos.filter(data_hora_triagem__gte=hoje_inicio)
    elif periodo_escolhido == '7dias':
        limite = agora - timedelta(days=7)
        atendimentos = atendimentos.filter(data_hora_triagem__gte=limite)
    elif periodo_escolhido == '30dias':
        limite = agora - timedelta(days=30)
        atendimentos = atendimentos.filter(data_hora_triagem__gte=limite)
    elif periodo_escolhido == 'personalizado':
        if data_inicio:
            atendimentos = atendimentos.filter(data_hora_triagem__date__gte=data_inicio)
        if data_fim:
            atendimentos = atendimentos.filter(data_hora_triagem__date__lte=data_fim)
            
    # 4. Aplica o Filtro de Busca por Nome (icontains ignora maiúsculas/minúsculas)
    if busca_nome:
        atendimentos = atendimentos.filter(paciente__nome_completo__icontains=busca_nome)
        
    atendimentos = atendimentos.order_by('-data_hora_triagem')
    
    # 5. REGRAS DE NEGÓCIO DA ENFERMAGEM (15 min e Médico)
    for atendimento in atendimentos:
        tempo_passado = agora - atendimento.data_hora_triagem
        passou_15_min = tempo_passado.total_seconds() > 900 # 900 segundos = 15 minutos
        
        # Se o médico reconheceu OU passou de 15 min, bloqueia a edição
        if atendimento.alerta_reconhecido or passou_15_min:
            atendimento.pode_editar = False
            if atendimento.alerta_reconhecido:
                atendimento.motivo_bloqueio = "Bloqueado: Reconhecido pelo médico"
            else:
                atendimento.motivo_bloqueio = "Bloqueado: Tempo limite excedido (>15min)"
        else:
            atendimento.pode_editar = True
            atendimento.motivo_bloqueio = ""
            
    contexto = {
        'nome_usuario': request.user.first_name or request.user.username,
        'perfil_nome': perfil.get_tipo_perfil_display(),
        'periodo_atual': periodo_escolhido,
        'data_inicio': data_inicio,
        'data_fim': data_fim,
        'busca': busca_nome,
        'atendimentos': atendimentos
    }
    
    return render(request, 'historico_triagem.html', contexto)

@login_required
def excluir_triagem(request, id):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    if perfil.tipo_perfil not in ['ENFERMAGEM', 'ADMIN']:
        return redirect('historico_triagem')
        
    atendimento = get_object_or_404(AtendimentoTriagem, id=id)
    
    # Validação de segurança dupla no servidor (garante que não burlem o link)
    tempo_passado = timezone.now() - atendimento.data_hora_triagem
    passou_15_min = tempo_passado.total_seconds() > 900
    
    if not atendimento.alerta_reconhecido and not passou_15_min:
        atendimento.delete()
        
    return redirect('historico_triagem')

@login_required
def editar_triagem(request, id):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    if perfil.tipo_perfil not in ['ENFERMAGEM', 'ADMIN']:
        return redirect('historico_triagem')
        
    atendimento = get_object_or_404(AtendimentoTriagem, id=id)
    
    tempo_passado = timezone.now() - atendimento.data_hora_triagem
    passou_15_min = tempo_passado.total_seconds() > 900
    
    if atendimento.alerta_reconhecido or passou_15_min:
        return redirect('historico_triagem') # Chuta de volta se estiver bloqueado
        
    contexto = {
        'nome_usuario': request.user.first_name or request.user.username,
        'perfil_nome': perfil.get_tipo_perfil_display(),
        'atendimento': atendimento # Mandamos o atendimento para a tela de triagem!
    }
    return render(request, 'triagem.html', contexto)

@login_required
def painel_admin(request):
    try:
        perfil = PerfilAcesso.objects.get(usuario=request.user)
        # Barreira de segurança nível máximo: Apenas ADMIN entra aqui
        if perfil.tipo_perfil != 'ADMIN':
            if perfil.tipo_perfil == 'ENFERMAGEM':
                return redirect('triagem')
            return redirect('medico')
    except PerfilAcesso.DoesNotExist:
        return redirect('sair')

    # NOVO: Recebe o termo de busca da tela
    busca_usuario = request.GET.get('busca_usuario', '')

    # Busca base de todos os usuários
    usuarios = PerfilAcesso.objects.select_related('usuario').prefetch_related('unidades').all()
    
    # NOVO: Aplica o filtro caso tenha digitado algo na busca
    if busca_usuario:
        usuarios = usuarios.filter(
            Q(usuario__first_name__icontains=busca_usuario) | 
            Q(usuario__username__icontains=busca_usuario) |
            Q(usuario__last_name__icontains=busca_usuario)
        )

    unidades = UnidadeSaude.objects.all()

    contexto = {
        'nome_usuario': request.user.first_name or request.user.username,
        'perfil_nome': perfil.get_tipo_perfil_display(),
        'lista_usuarios': usuarios,
        'lista_unidades': unidades,
        'busca_usuario': busca_usuario, # Envia o texto de volta para manter na caixinha
    }
    
    return render(request, 'painel_admin.html', contexto)

    import json
from django.http import JsonResponse

@login_required
def salvar_unidade(request):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    if perfil.tipo_perfil != 'ADMIN':
        return JsonResponse({'sucesso': False, 'erro': 'Acesso negado.'})

    if request.method == 'POST':
        try:
            dados = json.loads(request.body)
            unidade_id = dados.get('id')
            nome = dados.get('nome')

            if not nome:
                return JsonResponse({'sucesso': False, 'erro': 'O nome da unidade é obrigatório.'})

            # Se recebeu um ID, é edição. Se não, é criação.
            if unidade_id:
                unidade = UnidadeSaude.objects.get(id=unidade_id)
                unidade.nome = nome
                unidade.save()
            else:
                UnidadeSaude.objects.create(nome=nome)

            return JsonResponse({'sucesso': True})
        except Exception as e:
            return JsonResponse({'sucesso': False, 'erro': str(e)})
            
    return JsonResponse({'sucesso': False, 'erro': 'Método inválido.'})

@login_required
def toggle_unidade(request, id):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    if perfil.tipo_perfil != 'ADMIN':
        return JsonResponse({'sucesso': False, 'erro': 'Acesso negado.'})

    if request.method == 'POST':
        unidade = get_object_or_404(UnidadeSaude, id=id)
        unidade.ativo = not unidade.ativo # Inverte: se era True vira False, e vice-versa
        unidade.save()
        return JsonResponse({'sucesso': True})
        
    return JsonResponse({'sucesso': False, 'erro': 'Método inválido.'})

@login_required
def excluir_unidade(request, id):
    perfil = PerfilAcesso.objects.get(usuario=request.user)
    if perfil.tipo_perfil != 'ADMIN':
        return JsonResponse({'sucesso': False, 'erro': 'Acesso negado.'})

    if request.method == 'POST':
        try:
            unidade = get_object_or_404(UnidadeSaude, id=id)
            unidade.delete()
            return JsonResponse({'sucesso': True})
        except Exception as e:
            # Se a unidade já tiver triagens feitas, o banco não deixa apagar.
            return JsonResponse({'sucesso': False, 'erro': 'Não é possível excluir uma unidade que já possui pacientes vinculados. Tente apenas inativá-la.'})
            
    return JsonResponse({'sucesso': False, 'erro': 'Método inválido.'})


@login_required
def salvar_usuario(request):
    perfil_admin = PerfilAcesso.objects.get(usuario=request.user)
    if perfil_admin.tipo_perfil != 'ADMIN':
        return JsonResponse({'sucesso': False, 'erro': 'Acesso negado.'})

    if request.method == 'POST':
        try:
            dados = json.loads(request.body)
            user_id = dados.get('id')
            nome_completo = dados.get('nome_completo', '').strip()
            cpf = dados.get('cpf', '')
            username = dados.get('username', '')
            tipo_perfil = dados.get('tipo_perfil', '')
            unidades_ids = dados.get('unidades', [])

            # Divide o nome completo em Nome e Sobrenome para o padrão do Django
            partes_nome = nome_completo.split(' ', 1)
            first_name = partes_nome[0]
            last_name = partes_nome[1] if len(partes_nome) > 1 else ''

            if user_id:
                # É EDIÇÃO
                user = User.objects.get(id=user_id)
                user.first_name = first_name
                user.last_name = last_name
                user.username = username
                user.save()

                perfil = user.perfilacesso
                perfil.cpf = cpf
                perfil.tipo_perfil = tipo_perfil
                perfil.unidades.set(unidades_ids) # Atualiza as unidades vinculadas
                perfil.save()
            else:
                # É CRIAÇÃO (Novo Usuário)
                if User.objects.filter(username=username).exists():
                    return JsonResponse({'sucesso': False, 'erro': 'Este Código de Usuário já existe.'})

                # Cria o usuário já com a senha igual ao username
                user = User.objects.create_user(username=username, password=username, first_name=first_name, last_name=last_name)
                
                # Cria o perfil marcando que a senha DEVE ser trocada
                perfil = PerfilAcesso.objects.create(usuario=user, cpf=cpf, tipo_perfil=tipo_perfil, deve_trocar_senha=True)
                perfil.unidades.set(unidades_ids)

            return JsonResponse({'sucesso': True})
        except Exception as e:
            return JsonResponse({'sucesso': False, 'erro': str(e)})
            
    return JsonResponse({'sucesso': False, 'erro': 'Método inválido.'})

@login_required
def resetar_senha(request, id):
    perfil_admin = PerfilAcesso.objects.get(usuario=request.user)
    if perfil_admin.tipo_perfil != 'ADMIN':
        return JsonResponse({'sucesso': False, 'erro': 'Acesso negado.'})

    if request.method == 'POST':
        user = get_object_or_404(User, id=id)
        # Reseta a senha para ser igual ao username
        user.set_password(user.username)
        user.save()
        
        # Trava a conta novamente para forçar a troca
        perfil = user.perfilacesso
        perfil.deve_trocar_senha = True
        perfil.save()
        return JsonResponse({'sucesso': True})
        
    return JsonResponse({'sucesso': False, 'erro': 'Método inválido.'})

import re # Ferramenta do Python para buscar padrões de texto

@login_required
def pagina_trocar_senha(request):
    perfil = PerfilAcesso.objects.get(usuario=request.user)

    if request.method == 'POST':
        nova_senha = request.POST.get('nova_senha')
        confirmacao = request.POST.get('confirmacao')
        erro = None

        # --- NOVA VALIDAÇÃO DE COMPLEXIDADE ---
        if len(nova_senha) < 8:
            erro = 'A senha deve ter no mínimo 8 caracteres.'
        elif not re.search(r'[A-Z]', nova_senha):
            erro = 'A senha deve conter no mínimo 1 letra MAIÚSCULA.'
        elif not re.search(r'[a-z]', nova_senha):
            erro = 'A senha deve conter no mínimo 1 letra minúscula.'
        elif not re.search(r'\d', nova_senha):
            erro = 'A senha deve conter no mínimo 1 número.'
        elif not re.search(r'[!@#$%^&*(),.?":{}|<>\-_+=\[\]\\/\'~`]', nova_senha):
            erro = 'A senha deve conter no mínimo 1 símbolo (ex: @, #, !, $).'
        elif nova_senha != confirmacao:
            erro = 'As senhas digitadas não coincidem.'

        # Se encontrou algum erro na validação, devolve para a tela
        if erro:
            return render(request, 'trocar_senha.html', {'erro': erro})

        # Se passou por tudo, salva a nova senha!
        user = request.user
        user.set_password(nova_senha)
        user.save()

        # Libera o acesso do usuário
        perfil.deve_trocar_senha = False
        perfil.save()

        update_session_auth_hash(request, user)

        if perfil.tipo_perfil == 'ENFERMAGEM':
            return redirect('triagem')
        elif perfil.tipo_perfil in ['MEDICO', 'ADMINISTRATIVO']:
            return redirect('medico')
        else:
            return redirect('painel_admin')

    return render(request, 'trocar_senha.html')

@login_required
def verificar_alertas(request):
    unidade_id = request.session.get('unidade_id')
    if not unidade_id:
        return JsonResponse({'qtd': 0})
    
    # Conta quantas triagens estão aguardando o médico na unidade logada
    qtd = AtendimentoTriagem.objects.filter(
        unidade_id=unidade_id, 
        alerta_reconhecido=False
    ).count()
    
    return JsonResponse({'qtd': qtd})

@login_required
def relatorios(request):
    unidade_id = request.session.get('unidade_id')
    if not unidade_id:
        return redirect('pagina_login')
    
    unidade = UnidadeSaude.objects.get(id=unidade_id)

    # 1. Captura os Filtros
    periodo = request.GET.get('periodo', 'hoje')
    data_inicio = request.GET.get('data_inicio', '')
    data_fim = request.GET.get('data_fim', '')
    protocolo_filtro = request.GET.get('protocolo', 'todos')
    exportar = request.GET.get('exportar', '')

    # 2. Busca Base
    triagens = AtendimentoTriagem.objects.filter(unidade=unidade).select_related('paciente')

    # 3. Filtro de Data
    hoje = timezone.localtime(timezone.now()).date()
    if periodo == 'hoje':
        triagens = triagens.filter(data_hora_triagem__date=hoje)
    elif periodo == '7dias':
        triagens = triagens.filter(data_hora_triagem__date__gte=hoje - timedelta(days=7))
    elif periodo == '30dias':
        triagens = triagens.filter(data_hora_triagem__date__gte=hoje - timedelta(days=30))
    elif periodo == 'personalizado' and data_inicio and data_fim:
        triagens = triagens.filter(data_hora_triagem__date__range=[data_inicio, data_fim])

    # 4. Filtro de Protocolo
    if protocolo_filtro != 'todos':
        triagens = triagens.filter(protocolo__iexact=protocolo_filtro)

    triagens = triagens.order_by('-data_hora_triagem')

    # 5. Calcula os Totais do Rodapé
    totais = {
        'NEWS': {'Alto': 0, 'Médio': 0, 'Baixo': 0},
        'PEWS': {'Alto': 0, 'Médio': 0, 'Baixo': 0},
        'MEOWS': {'Alto': 0, 'Médio': 0, 'Baixo': 0},
    }
    for t in triagens:
        prot = t.protocolo.upper()
        risco = t.classificacao_risco
        if prot in totais and risco in totais[prot]:
            totais[prot][risco] += 1

    # ==========================================
    # LÓGICA DE EXPORTAÇÃO PARA EXCEL (CSV)
    # ==========================================
    if exportar == 'excel':
        # Configura o arquivo para ser baixado pelo navegador, compatível com Excel Br
        response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
        response['Content-Disposition'] = f'attachment; filename="Relatorio_Triagem_{unidade.nome}.csv"'
        writer = csv.writer(response, delimiter=';')

        # Cabeçalho do Documento
        writer.writerow(['RELATÓRIO GERENCIAL DE TRIAGEM CLÍNICA'])
        writer.writerow(['Unidade:', unidade.nome])
        writer.writerow(['Período:', periodo.upper()])
        writer.writerow(['Protocolo:', protocolo_filtro.upper()])
        writer.writerow([]) # Linha em branco
        
        # Cabeçalho da Tabela
        writer.writerow(['Paciente', 'Data do Atendimento', 'Protocolo', 'Score', 'Classificação de Risco'])
        
        # Linhas de Dados
        for t in triagens:
            data_formatada = timezone.localtime(t.data_hora_triagem).strftime('%d/%m/%Y %H:%M')
            writer.writerow([t.paciente.nome_completo, data_formatada, t.protocolo, t.score_final, t.classificacao_risco])
            
        # Rodapé de Totais
        writer.writerow([])
        writer.writerow(['RESUMO GERAL DE CLASSIFICAÇÃO'])
        for prot, riscos in totais.items():
            if protocolo_filtro == 'todos' or protocolo_filtro.upper() == prot:
                writer.writerow([f'Protocolo {prot}:', f"Alto: {riscos['Alto']}", f"Médio: {riscos['Médio']}", f"Baixo: {riscos['Baixo']}"])

        return response

    # ==========================================
    # RENDERIZAR TELA HTML NORMAL
    # ==========================================
    contexto = {
        'triagens': triagens,
        'totais': totais,
        'unidade_nome': unidade.nome,
        'periodo_atual': periodo,
        'data_inicio': data_inicio,
        'data_fim': data_fim,
        'protocolo_atual': protocolo_filtro,
        'nome_usuario': request.user.first_name or request.user.username,
        'perfil_nome': request.user.perfilacesso.get_tipo_perfil_display(),
    }
    
    return render(request, 'relatorios.html', contexto)